import re

def clean_lines(raw):
    """Clean raw text lines from various formats."""
    lines = []
    for line in raw.split("\n"):
        line = line.strip()
        if not line: continue
        if line[0].isdigit() and "." in line:
            line = line.split(".", 1)[1].strip()
        line = line.strip('"').strip("'").strip("-• ")
        lines.append(line)
    return lines

def clean_lines2(raw):
    """Clean raw text lines keeping only language-specific characters."""
    lines = []
    # Regex allows:
    # a-zA-Z basic letters
    # äöüÄÖÜß (German)
    # áéíóúüñÁÉÍÓÚÜÑ (Spanish)
    # dash and spaces
    pattern = r'[^a-zA-ZäöüÄÖÜßáéíóúüñÁÉÍÓÚÜÑ\-\s]'
    for line in raw.split('\n'):
        line = re.sub(pattern, '', line)
        line = line.strip()
        if line:
            line = line.replace("*", "")
            lines.append(line)
    return lines