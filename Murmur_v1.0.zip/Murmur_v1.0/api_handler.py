from openai import OpenAI
from config import OPENAI_API_KEY,CONFIG,LAST_CALL
import re
import datetime
client = OpenAI(api_key=OPENAI_API_KEY)
timex=0
timey=0

def get_word_pairs(selected_words):
    """Get word pairs from OpenAI."""
    word_prompt = (
        f"Out of the following 20 words, where each entry in the list is [language,[words]], pick exactly 10 that are the most commonly used or easiest to learn. "
        f"Return them in this format: A list of lists where each sublist is strictly: [Word in foreign language, English translation,emoji for language,Sample sentence in language,US emoji, English translation of that sentence], dont need captions, just the element, neatly in a list. I DO NOT want the name of language anywhere, except for emoji, i want just one single list of 10 sublists as output "
        f"Generated 10 sentences should be relevant to the following context or scenarios: {CONFIG['customization']} Return in this exact list form, just 6 entries per sublist.\n\n"
        + "\n" + str(selected_words)
    )

    completion = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": word_prompt}]
    )

    raw_output = completion.choices[0].message.content
    print(raw_output)
    #print("RAW OUTPUT FROM OPENAI:\n", raw_output)
    word_pairs = clean_lines0(raw_output)
    print(word_pairs)
    global timex
    global timey
    timex = datetime.datetime.now()
    timey=len(word_pairs)
    return word_pairs, timex

def get_sentences(word_list):
    """Get example sentences from OpenAI."""
    sentence_prompt = (
        f"For each of the following words in language where each entry in the list is [language,[words]], give a sample sentence in language and its English translation. "
        f"Format:[emoji for language] [insert sentence in language] \n [emoji for english] [insert translation in english]"
        + str(word_list)
    )

    sentence_completion = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": sentence_prompt}]
    )
    return sentence_completion.choices[0].message.content

def get_quotes(english_words, language):
    """Get motivational quotes from OpenAI."""
    prompt = f"For each of the words in {english_words} give me a motivational or iconic quotes or popular saying that includes the word or the closest relation, with author and year. Format: Quote — Author (Year). If it is a popular saying, use '{language} saying' as author. No quotes, no numbering, no bullet points."
    
    completion = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": prompt}]
    )
    return completion.choices[0].message.content



def clean_lines0(input_string):
    # Remove all extra whitespace (including tabs and newlines)
    cleaned = re.sub(r'\s+', ' ', input_string.strip())
    
    # Split into individual entries
    entries = re.findall(r'\[([^\[\]]+)\]', cleaned)
    
    # Clean each entry and restructure
    result = []
    for entry in entries:
        # Split components, handling commas inside quotes
        components = re.split(r',\s*(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)', entry)
        cleaned_components = []
        for comp in components:
            comp = comp.strip()
            # Remove surrounding quotes if present
            if (comp.startswith('"') and comp.endswith('"')) or \
               (comp.startswith("'") and comp.endswith("'")):
                comp = comp[1:-1]
            # Remove any remaining extra spaces
            comp = re.sub(r'\s+', ' ', comp.strip())
            cleaned_components.append(comp)
        
        # Restructure: [0, 1, 2+3, 4+5]
        if len(cleaned_components) == 6:
            merged_entry = [
                cleaned_components[0],  # Word (e.g., "recolas")
                cleaned_components[1],  # Translation (e.g., "snacks")
                f"{cleaned_components[2]} {cleaned_components[3]}",  # 🇪🇸 + Sentence
                f"{cleaned_components[4]} {cleaned_components[5]}"   # 🇺🇸 + Sentence
            ]
            result.append(merged_entry)
    
    return result

def t2():
    return timex