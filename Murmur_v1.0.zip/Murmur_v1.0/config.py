# Configuration and constants
import datetime
import json
import os
from typing import Dict, Any
import sys

# Language settings
LANGUAGE = 'Spanish'
LANGUAGE_EMOJI = '🇪🇸' if LANGUAGE == 'Spanish' else '🇩🇪'
ENG_EMOJI = '🇺🇸'

# App settings
RESET_TIMEOUT = 1800

#SET YOUR API KEY HERE
OPENAI_API_KEY = ""
LAST_CALL=0

# Paths
CSV_PATH = "assets\\languages\\"

# Time settings
import datetime

def resource_path(relative_path):
    """Get absolute path to resource, works for dev and for PyInstaller .exe"""
    try:
        base_path = sys._MEIPASS  # this exists when in .exe mode
    except Exception:
        base_path = os.path.abspath(".")

    return os.path.join(base_path, relative_path)

def is_valid_time(timex):
    now = datetime.datetime.now()
    
    # Check weekday (Mon-Fri) and hours (8am-7pm)
    time_condition = now.weekday() < 5 and 8 <= now.hour < 19
    
    # Check if tomes exists and calculate time difference
    if timex:
        time_diff = abs(now - timex).total_seconds()
        return time_condition and (time_diff >= 1800)  # 1800 seconds = 30 minutes
    else:
        return time_condition  # If no previous time, just check basic conditions

import json
import os
from typing import List, Dict, Any

THEMES = {
    "dark": {
        "bg": "#1e1e1e",
        "text": "white",
        "word_foreign": "green",
        "word_english": "red", 
        "sentence_foreign": "cyan",
        "sentence_english": "magenta",
        "next_word_label": "white",
        "quote": "yellow",
        "meta": "yellow",
        "footer": "gray"
    },
    "light": {
        "bg": "#EDEDED",
        "text": "black",
        "word_foreign": "darkgreen",
        "word_english": "red",
        "sentence_foreign": "blue",
        "sentence_english": "purple",
        "next_word_label": "black",
        "quote": "orange",
        "meta": "orange",
        "footer": "darkgray"
    }
}


DEFAULT_CONFIG = {
    "theme": "dark",
    "colors": THEMES["dark"],
    "languages": ["Spanish", "German"],
    "api_frequency": '2',
    "customization": "",
    "premium": False,
    "window_size": "500x750"
}

# Available languages (top 25 by usage)
'''LANGUAGES = [
    "Spanish", "French", "German", "Japanese",
    "Russian", "Portuguese", "Chinese", "Hindi", "Arabic",
    "Italian", "Korean", "Dutch", "Turkish", "Polish",
    "Swedish", "Norwegian", "Danish", "Finnish", "Greek",
    "Czech", "Hungarian", "Romanian", "Thai", "Vietnamese"
]'''
LANGUAGES = [
    "Spanish", "French", "German", "Japanese",
    "Russian", "Chinese", "Italian"
]

# Theme configurations

def load_config() -> Dict[str, Any]:
    config_path = resource_path("assets\\config\\config.json")
    if os.path.exists(config_path):
        try:
            with open(config_path, "r") as f:
                loaded = json.load(f)
                # Ensure colors match selected theme
                loaded["colors"] = THEMES.get(loaded["theme"], THEMES["dark"])
                return {**DEFAULT_CONFIG, **loaded}
        except:
            print('Cannot load config')
            pass
    return DEFAULT_CONFIG

def save_config(config: Dict[str, Any]):
    config_path = get_user_config_path()
    with open(config_path, "w") as f:
        json.dump(config, f, indent=2)

def get_user_config_path():
    """Get writable user config path"""
    if os.name == 'nt':
        base = os.getenv('APPDATA') or os.path.expanduser('~\\AppData\\Roaming')
    else:
        base = os.path.expanduser("~/.config")
    config_dir = os.path.join(base, "Murmur")
    os.makedirs(config_dir, exist_ok=True)
    return os.path.join(config_dir, "config.json")

def load_user_config() -> Dict[str, Any]:
    user_path = get_user_config_path()
    if os.path.exists(user_path):
        with open(user_path, "r") as f:
            return json.load(f)
    return load_config()

CONFIG = load_user_config()
print(CONFIG)



